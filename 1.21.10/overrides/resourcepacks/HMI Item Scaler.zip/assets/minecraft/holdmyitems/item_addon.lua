local itemVar = item
local matricesVar = matrices

if bl or bl == false then
	
else
	itemVar = context.item
	matricesVar = context.matrices
end

local itemsToShrink = {${itemsToShrink}} or {
    "minecraft:diamond_sword",
    "minecraft:string"
}

local size = ${itemSize}
local sizeAll = ${itemSizeAll}

if ${scaleSpecific} then
    for _, v in ipairs(itemsToShrink) do
        if I:isOf(itemVar, Items:get(v)) then
            M:scale(matricesVar, size, size, size)
        end
    end
end

if ${scaleAll} then
    M:scale(matricesVar, sizeAll, sizeAll, sizeAll)
end

--// ✦ By maingvaldsen ✦ \\--