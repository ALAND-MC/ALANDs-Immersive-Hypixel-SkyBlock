int sampleBlockType(sampler2D tex, vec2 uv) {
    vec4 rawCol = texture(tex, uv);
    int alphaInt = int(rawCol.a * 255.0 + 0.5); // +0.5 für Rundungssicherheit
    
    int animType = 0;
    
    if (alphaInt == 125) {
        animType = 1;
    }
    
    return animType;
}