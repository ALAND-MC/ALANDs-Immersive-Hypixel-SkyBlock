#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>
#moj_import <minecraft:projection.glsl>

#moj_import <minecraft:drksc_core/vert.glsl>
#moj_import <minecraft:drksc_core/lava_calc.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

vec4 minecraft_sample_lightmap(sampler2D lightMap, ivec2 uv) {
    return texture(lightMap, clamp((uv / 256.0) + 0.5 / 16.0, vec2(0.5 / 16.0), vec2(15.5 / 16.0)));
}

void main() {
    vec3 pos = Position + (ChunkPosition - CameraBlockPos) + CameraOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    
    vec4 color = Color * minecraft_sample_lightmap(Sampler2, UV2);

    int blockType = sampleBlockType(Sampler0, UV0);
    if (blockType == 1) {
        vec3 posInEightChunks = (Position + ChunkPosition) / 128; // 0..1
        color.a = 0.5;
        color.rgb = posInEightChunks;
    }

    vertexColor = color;
    texCoord0 = UV0;
}
