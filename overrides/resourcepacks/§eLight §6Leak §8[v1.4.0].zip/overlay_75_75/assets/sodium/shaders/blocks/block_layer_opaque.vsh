#version 330 core

#import <sodium:include/fog.glsl>
#import <sodium:include/chunk_vertex.glsl>
#import <sodium:include/chunk_matrices.glsl>

#import <minecraft:include/drksc_core/vert.glsl>
#import <minecraft:include/drksc_core/lava_calc.glsl>

out vec4 v_Color;
out vec2 v_TexCoord;

flat out uint v_Material;

#ifdef USE_FOG
out vec2 v_FragDistance;
out float fadeFactor;
#endif

uniform vec3 u_RegionOffset;
uniform vec2 u_TexCoordShrink;

uniform sampler2D u_LightTex; // The light map texture sampler
uniform sampler2D u_BlockTex; // The block texture sampler

uniform int u_CurrentTime;
uniform float u_FadePeriodInv;

uniform float u_GameTime; // Gametime from 0..1 in 24000 ticks

layout(std140) uniform ChunkData {
    ivec4 u_chunkFades[64]; // Packing into ivec4 is needed to avoid wasting 3KB...
};

uvec3 _get_relative_chunk_coord(uint pos) {
    // Packing scheme is defined by LocalSectionIndex
    return uvec3(pos) >> uvec3(5u, 0u, 2u) & uvec3(7u, 3u, 7u);
}

vec3 _get_draw_translation(uint pos) {
    return _get_relative_chunk_coord(pos) * vec3(16.0);
}

void main() {
    _vert_init();

    // Transform the chunk-local vertex position into world model space
    vec3 translation = u_RegionOffset + _get_draw_translation(_draw_id);
    vec3 position = _vert_position + translation;

#ifdef USE_FOG
    v_FragDistance = getFragDistance(position);

    int chunkId = int(_draw_id);
    int chunkFade = u_chunkFades[chunkId >> 2][chunkId & 3];
    int fadeTime = u_CurrentTime - chunkFade;
    float elapsed = float(fadeTime);
    float fade = clamp(float(u_CurrentTime - chunkFade) * u_FadePeriodInv, 0.0, 1.0);
    fadeFactor = (chunkFade < 0) ? 1.0 : fade;
#endif

    // Transform the vertex position into model-view-projection space
    gl_Position = u_ProjectionMatrix * u_ModelViewMatrix * vec4(position, 1.0);

    // Add the light color to the vertex color, and pass the texture coordinates to the fragment shader
    v_TexCoord = (_vert_tex_diffuse_coord_bias * u_TexCoordShrink) + _vert_tex_diffuse_coord; // FMA for precision
    vec4 color = _vert_color * texture(u_LightTex, _vert_tex_light_coord);

    // check for lava -> calculate color
    int blockType = sampleBlockType(u_BlockTex, v_TexCoord);
    
    if (blockType == 1) {
        vec3 posInEightChunks = (_get_draw_translation(_draw_id) + _vert_position) / 128; // 0..1
        color.a = 0.5;
        color.rgb = posInEightChunks;
    }

    v_Color = color;

    v_Material = _material_params;
}
